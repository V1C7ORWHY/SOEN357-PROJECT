exports.getLogin = (req, res) => {
    res.render('login', { title: 'NiceShopping - Login/Signup' });
};
