exports.getSettings = (req, res) => {
    res.render('settings', { title: 'NiceShopping - Settings' });
};
