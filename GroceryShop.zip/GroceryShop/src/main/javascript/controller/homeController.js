exports.getHome = (req, res) => {
    res.render('index', { title: 'NiceShopping - Home' });
};
